README for Flight Delay Prediction Project

Participants:
- Siddharth Bahekar: 002417718
- Rachita Shah: 002482615

Project Overview:
This midterm project focuses on predicting flight delays using machine learning algorithms.The project includes data analysis,
feature engineering, and the application of various machine learning models to analyze flight delays in 2023.

File Names and Descriptions:
- 002417718_Siddharth_Bahekar.ipynb: This file contains the Jupyter notebook with the complete analysis and model-building process.
- 002417718_Siddharth_Analysis.pdf: This file includes the project report summarizing the methodologies and findings.
- Flight Delay 2023.csv: This file consists of the dataset used in this project, containing flight delay information for the year 2023.
- ReadMe.txt: This file contains the metadata about the project, including details about the files and group members.

Contributions:

Siddharth's Contributions:
1. Found the dataset from Kaggle.
2. Imported libraries and loaded the dataset.
3. Checked for missing values and displayed summary statistics.
4. Converted 'month' to a categorical data type.
5. Developed a function to check and treat skewness.
6. Selected relevant columns for correlation analysis.
7. Conducted analysis on:
   - Delay distribution.
   - Delay trends by airport.
8. Applied Logistic Regression and Random Forest models.
9. Conducted analysis on cancellations and diversions.

Rachita's Contributions:
1. Decided to work only on the 2023 data instead of using all records.
2. Displayed basic information about the dataset and the first few rows.
3. Wrote a function to detect and remove outliers using the IQR method.
4. Checked class imbalance for 'carrier.'
5. Conducted analysis on:
   - Delay types proportion.
   - Carrier performance.
6. Analyzed delay types, average delays by carrier, and delays by month.
7. Applied Decision Tree model and Gradient Boosting.

Joint Contributions (Siddharth and Rachita):
- Compared machine learning algorithms.
- Worked together on the final report, actively participating in Zoom meetings and collaborating to build the project.
